<!-- About Page -->
<section class="page-section">
    <div class="container">
        <h1 class="page-title">About Us</h1>
        <div class="content-box">
            <h2>Elderly Care Residence Management & Emergency Support Platform</h2>
            <p>
                Our platform provides comprehensive care and management solutions for elderly care residences. 
                We combine modern technology with compassionate care to ensure the well-being of our residents.
            </p>
            
            <h3>Our Mission</h3>
            <p>
                To provide a seamless, efficient, and caring environment for elderly residents through 
                advanced management systems and 24/7 emergency support.
            </p>
            
            <h3>Key Features</h3>
            <ul>
                <li>Real-time health monitoring and tracking</li>
                <li>Personalized meal planning based on dietary requirements</li>
                <li>24/7 emergency alert and response system</li>
                <li>Transparent financial management</li>
                <li>Comprehensive reporting and analytics</li>
                <li>Premium care services</li>
            </ul>
        </div>
    </div>
</section>
