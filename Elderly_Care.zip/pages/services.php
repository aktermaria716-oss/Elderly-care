<!-- Services Page -->
<section class="page-section">
    <div class="container">
        <h1 class="page-title">Our Services</h1>
        
        <div class="services-list">
            <div class="service-item">
                <h3><i class="fas fa-heartbeat"></i> Health Monitoring</h3>
                <p>Daily tracking of vital health metrics including sugar levels, blood pressure, sleep patterns, and medication intake.</p>
            </div>
            
            <div class="service-item">
                <h3><i class="fas fa-utensils"></i> Meal Management</h3>
                <p>Personalized meal plans based on individual dietary needs (diabetes-friendly, low-salt, soft food, heart patient diet).</p>
            </div>
            
            <div class="service-item">
                <h3><i class="fas fa-exclamation-triangle"></i> Emergency Support</h3>
                <p>Instant emergency alert system with immediate staff notification and response tracking.</p>
            </div>
            
            <div class="service-item">
                <h3><i class="fas fa-money-bill-wave"></i> Financial Management</h3>
                <p>Transparent accounting with support for multiple payment methods (Card, bKash, Rocket) and monthly reports.</p>
            </div>
            
            <div class="service-item">
                <h3><i class="fas fa-star"></i> Premium Services</h3>
                <p>Premium package (<?php echo formatCurrency(PREMIUM_PACKAGE_PRICE); ?>) includes extra checkups, priority medical response, private caregiver, and special meals.</p>
            </div>
            
            <div class="service-item">
                <h3><i class="fas fa-chart-line"></i> Health Reports</h3>
                <p>Monthly health improvement tracking and detailed reports for residents and family members.</p>
            </div>
        </div>
    </div>
</section>
