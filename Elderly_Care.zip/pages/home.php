<!-- Home Page -->
<section class="hero-section">
    <div class="container">
        <div class="hero-content">
            <h1 class="hero-title">Elderly Care Residence Management</h1>
            <p class="hero-subtitle">Comprehensive care and emergency support platform for elderly residents</p>
            <div class="hero-buttons">
                <a href="index.php?page=login" class="btn btn-large btn-primary">
                    <i class="fas fa-sign-in-alt"></i> Sign In
                </a>
                <a href="index.php?page=about" class="btn btn-large btn-outline">
                    <i class="fas fa-info-circle"></i> Learn More
                </a>
            </div>
        </div>
    </div>
</section>

<section class="features-section">
    <div class="container">
        <h2 class="section-title">Key Features</h2>
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-heartbeat"></i>
                </div>
                <h3>Health Monitoring</h3>
                <p>Track daily health metrics including sugar levels, blood pressure, and overall condition.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-utensils"></i>
                </div>
                <h3>Meal Management</h3>
                <p>Select meals based on dietary requirements with personalized meal plans.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <h3>Emergency Support</h3>
                <p>24/7 emergency alert system for immediate medical assistance.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <h3>Health Reports</h3>
                <p>Monthly health improvement tracking and detailed reports.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <h3>Financial Transparency</h3>
                <p>Track deposits, withdrawals, and expenses with detailed financial records.</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-star"></i>
                </div>
                <h3>Premium Services</h3>
                <p>Extra checkups, priority response, private caregiver, and special meals.</p>
            </div>
        </div>
    </div>
</section>
