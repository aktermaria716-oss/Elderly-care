<!-- Contact Page -->
<section class="page-section">
    <div class="container">
        <h1 class="page-title">Contact Us</h1>
        <div class="contact-content">
            <div class="contact-info">
                <h3>Get in Touch</h3>
                <div class="contact-item">
                    <i class="fas fa-phone"></i>
                    <div>
                        <strong>Phone:</strong>
                        <p>+880 1234 567890</p>
                    </div>
                </div>
                <div class="contact-item">
                    <i class="fas fa-envelope"></i>
                    <div>
                        <strong>Email:</strong>
                        <p>info@elderlycare.com</p>
                    </div>
                </div>
                <div class="contact-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <div>
                        <strong>Address:</strong>
                        <p>Dhaka, Bangladesh</p>
                    </div>
                </div>
                <div class="contact-item">
                    <i class="fas fa-clock"></i>
                    <div>
                        <strong>Emergency:</strong>
                        <p>24/7 Emergency Support Available</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
